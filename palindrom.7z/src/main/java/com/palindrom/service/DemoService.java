package com.palindrom.service;

public interface DemoService {

	String insertLongestPalindrom(String input);

	String getLongestPalindrom(String input);

}
